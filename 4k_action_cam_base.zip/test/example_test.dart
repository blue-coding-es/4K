import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Test de ejemplo', () {
    expect(2 + 2, 4);
  });
}
